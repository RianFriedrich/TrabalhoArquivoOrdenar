package projeto;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class LerArquivo {
	
	
	void lerArquivo(int lim, int quant) throws FileNotFoundException {
		try {
		List<numeros> listaNumeros;
		listaNumeros = new ArrayList<>();
		FileWriter fr = new FileWriter(new File("C:\\Users\\laboratorio\\Desktop\\TrabalhoLerArquivo\\arquivo.txt"));
		BufferedWriter bw = new BufferedWriter(fr);
		int i = 0;
		
		while (i<=quant) {
			Random rand = new Random();
			int valor = rand.nextInt(lim);
			numeros n = new numeros(valor);
			i++;
			listaNumeros.add(n);
			bw.write(valor);
			System.out.println(valor);
			bw.close();
			}
		}catch(Exception e){
			System.out.println("Erro "+ e.getMessage());
		}			
	}
	
	void lerLista() {
		try {
			List<Integer> ordenaNumeros = new ArrayList<Integer>();
			int i = 0;
			while(true) {
				FileReader fr = new FileReader(new File("C:\\Users\\laboratorio\\Desktop\\TrabalhoLerArquivo\\arquivo.txt"));
				BufferedReader bf = new BufferedReader(fr);
				String nextLine = bf.readLine();
				while (nextLine == ""){
					break;
				}
				ordenaNumeros.add(Integer.parseInt(nextLine));
				System.out.println(nextLine);
			i++;
			}
		}catch(Exception e){
			System.out.println("Erro "+ e.getMessage());
		}		
	}
}